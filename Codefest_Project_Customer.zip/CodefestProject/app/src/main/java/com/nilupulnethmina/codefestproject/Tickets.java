package com.nilupulnethmina.codefestproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.nilupulnethmina.codefestproject.Model.Customer;
import com.nilupulnethmina.codefestproject.Model.Ticket;

import java.net.URI;
import java.util.List;

public class Tickets extends AppCompatActivity {

    private Spinner spinner;
    EditText title, message, atachfile;
    Button addfile, submit;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private StorageReference storageRef = FirebaseStorage.getInstance().getReference();
    private Uri filePath;
    private String customerdoc;
    private String file_path;
    private String ticket_type;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Tickets");
        setContentView(R.layout.activity_tickets);

        title = findViewById(R.id.ticket_title);
        message = findViewById(R.id.ticket_message);
        atachfile = findViewById(R.id.atachfilename);

        addfile = findViewById(R.id.button2);
        addfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent fileChoser = new Intent(Intent.ACTION_GET_CONTENT);
                fileChoser.setType("*/*");
                startActivityForResult(fileChoser, 1);
            }
        });

        spinner = findViewById(R.id.spinner);
        String[] categories = {"Information Request", "Complain", "Compliment"};
        ArrayAdapter arrayAdapter = new ArrayAdapter(this, R.layout.support_simple_spinner_dropdown_item, categories);
        spinner.setAdapter(arrayAdapter);

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        String user_email = user.getEmail();

        db.collection("Customer").whereEqualTo("cus_email", user_email).get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        List<Customer> customers = queryDocumentSnapshots.toObjects(Customer.class);
                        if (customers.size() > 0) {
                            DocumentSnapshot snapshot = queryDocumentSnapshots.getDocuments().get(0);
                            customerdoc = snapshot.getId();
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        });

        submit = findViewById(R.id.button5);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ticket_type = spinner.getSelectedItem().toString();
                if (filePath != null) {
                    file_path = "Ticket_Attach_File/" + System.currentTimeMillis();
                    UploadTask uploadTask = storageRef.child(file_path).putFile(filePath);
                    uploadTask.addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception exception) {
                        }
                    }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            taskSnapshot.getUploadSessionUri();
                        }
                    });
                } else {
                    file_path = null;
                }

                Ticket t = new Ticket();
                t.setTitle_ticket(title.getText().toString());
                t.setMessage_ticket(message.getText().toString());
                t.setCustomer_doc_id(customerdoc);
                t.setAttach_file_ticket(file_path);
                t.setType_ticket(ticket_type);
                t.setStatus("Not View");

                db.collection("Tickets").add(t).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        finish();
                        Intent intent = new Intent(Tickets.this, Home.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                });
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
                filePath = data.getData();
                atachfile.setText(filePath.getLastPathSegment());
            }
        }
    }
}