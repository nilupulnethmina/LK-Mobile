package com.nilupulnethmina.codefestproject.Adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.nilupulnethmina.codefestproject.Model.News;
import com.nilupulnethmina.codefestproject.Model.Product;
import com.nilupulnethmina.codefestproject.R;

import java.util.List;

public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.MyViewHolder> {

    private Context mCtx;
    private List<News> p_list;
    private LayoutInflater inflater;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private StorageReference storageRef = FirebaseStorage.getInstance().getReference();
    private String price;
    private String name;
    private String productid;

    public NewsAdapter(Context mCtx, List<News> p_list) {
        this.mCtx = mCtx;
        this.p_list = p_list;
        this.inflater = LayoutInflater.from(mCtx);
    }

    @NonNull
    @Override
    public NewsAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.news_layout, parent, false);
        return new NewsAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NewsAdapter.MyViewHolder holder, int position) {
        News news = p_list.get(position);
        if (!news.equals("null")) {
            holder.txt1.setText(news.getNews_title());
            holder.txt2.setText(news.getNews_message());

            db.collection("Product").document(news.getProduct_docunemt()).get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot snapshot) {
                            price = snapshot.get("product_price") + "";
                            name = snapshot.get("product_brand_name") + " " + snapshot.get("product_name");
                            holder.txt3.setText(name);
                            holder.txt4.setText("Rs. " + price + ".00");

                            String img_url = snapshot.get("priduct_image") + "";
                            storageRef.child(img_url).getBytes(1024 * 1024).addOnSuccessListener(new OnSuccessListener<byte[]>() {
                                @Override
                                public void onSuccess(byte[] bytes) {
                                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                                    holder.imgproduct.setImageBitmap(bitmap);
                                }
                            });
                            Glide.with(mCtx).load(img_url).into(holder.imgproduct);

                        }
                    }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {

                }
            });

            holder.linearLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });
        } else {
            Toast.makeText(mCtx, "No Product Found", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public int getItemCount() {
        return p_list.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView txt1, txt2, txt3, txt4;
        LinearLayout linearLayout;
        ImageView imgproduct;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            txt1 = itemView.findViewById(R.id.textView);
            txt2 = itemView.findViewById(R.id.textView2);
            txt3 = itemView.findViewById(R.id.textView4);
            txt4 = itemView.findViewById(R.id.textView5);
            imgproduct = itemView.findViewById(R.id.imageView4);
            linearLayout = itemView.findViewById(R.id.news_content);

        }
    }
}