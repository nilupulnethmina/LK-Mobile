package com.nilupulnethmina.codefestprojectadmin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.firebase.ui.auth.AuthUI;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.nilupulnethmina.codefestprojectadmin.Model.Admin;

import java.util.List;

import kotlin.jvm.internal.Intrinsics;

public class Home extends AppCompatActivity {

    ImageView imageView;
    TextView admin_name, admin_email, admin_mobile;
    Button btn_logout, btn_new_product, btn_tickets, btn_addd_news;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private StorageReference storageRef = FirebaseStorage.getInstance().getReference();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        btn_addd_news = findViewById(R.id.button3);
        btn_addd_news.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Home.this, AddNews.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });

        btn_new_product = findViewById(R.id.button2);
        btn_new_product.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Home.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });

        btn_tickets = findViewById(R.id.button4);
        btn_tickets.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Home.this, Tickets.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });

        imageView = findViewById(R.id.profile_image);

        admin_name = findViewById(R.id.profile_name);
        admin_email = findViewById(R.id.profile_email);
        admin_mobile = findViewById(R.id.profile_mobile);

        btn_logout = findViewById(R.id.btnlogout);
        btn_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AuthUI.getInstance()
                        .signOut(Home.this)
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            public void onComplete(@NonNull Task<Void> task) {
                                Intent intent = new Intent(Home.this, Login.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                                startActivity(intent);
                                finish();
                            }
                        });
            }
        });

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        String user_email = user.getEmail();

        db.collection("Admin").whereEqualTo("admin_email", user_email).get().addOnSuccessListener(
                new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        List<Admin> riders = queryDocumentSnapshots.toObjects(Admin.class);
                        if (riders.size() > 0) {
                            Admin customer = riders.get(0);
                            admin_name.setText(customer.getAdmin_name());
                            admin_email.setText(customer.getAdmin_email());
                            admin_mobile.setText(customer.getAdmin_mobile());
                            Uri profileImage = user.getPhotoUrl();
                            Glide.with(Home.this).load(profileImage).into(imageView);
                        }
                    }
                }
        ).addOnFailureListener(
                new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                }
        );
    }
}