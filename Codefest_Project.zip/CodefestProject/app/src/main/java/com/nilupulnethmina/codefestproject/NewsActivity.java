package com.nilupulnethmina.codefestproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.nilupulnethmina.codefestproject.Adapter.NewsAdapter;
import com.nilupulnethmina.codefestproject.Adapter.ProductAapter;
import com.nilupulnethmina.codefestproject.Model.News;

import java.util.List;


public class NewsActivity extends AppCompatActivity {

    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private RecyclerView recyclerView;
    private NewsAdapter newsAapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("News");
        setContentView(R.layout.activity_news_activity);

        db.collection("News").get().addOnSuccessListener(
                new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        List<News> news = queryDocumentSnapshots.toObjects(News.class);
                        recyclerView = findViewById(R.id.news_contect);
                        newsAapter = new NewsAdapter(NewsActivity.this, news);
                        recyclerView.setLayoutManager(new LinearLayoutManager(NewsActivity.this));
                        recyclerView.setAdapter(newsAapter);
                    }
                }
        ).addOnFailureListener(
                new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                }
        );

    }
}