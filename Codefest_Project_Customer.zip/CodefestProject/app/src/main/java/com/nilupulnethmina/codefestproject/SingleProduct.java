package com.nilupulnethmina.codefestproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.tv.TvView;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.nilupulnethmina.codefestproject.Adapter.ProductAapter;
import com.nilupulnethmina.codefestproject.Model.Buy;
import com.nilupulnethmina.codefestproject.Model.Customer;
import com.nilupulnethmina.codefestproject.Model.Product;

import java.util.Date;
import java.util.List;

public class SingleProduct extends AppCompatActivity {

    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private StorageReference storageRef = FirebaseStorage.getInstance().getReference();
    public static String documentid;
    EditText card_no, ex_mo, ex_ye, s_co;
    private String price;
    private String name;
    private String customerdoc;
    private String qty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_product);

        ImageView imageView = findViewById(R.id.imageView3);
        TextView textView1 = findViewById(R.id.textView_name);
        TextView textView2 = findViewById(R.id.textViewprice);
        TextView textView3 = findViewById(R.id.textViewdescription);

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        db.collection("Customer").whereEqualTo("cus_email", user.getEmail()).get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        List<Customer> customers = queryDocumentSnapshots.toObjects(Customer.class);
                        if (customers.size() > 0) {
                            DocumentSnapshot snapshot = queryDocumentSnapshots.getDocuments().get(0);
                            customerdoc = snapshot.getId();
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        });

        card_no = findViewById(R.id.card);
        ex_mo = findViewById(R.id.month);
        ex_ye = findViewById(R.id.year);
        s_co = findViewById(R.id.code);

        Button btn_buy = findViewById(R.id.buttonbuy);

        db.collection("Product").document(documentid).get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot snapshot) {
                        System.out.println(snapshot.getId());
                        price = snapshot.get("product_price") + "";
                        name = snapshot.get("product_brand_name") + " " + snapshot.get("product_name");
                        String img_url = snapshot.get("priduct_image").toString();
                        qty = snapshot.get("product_qty") + "";
                        storageRef.child(img_url).getBytes(1024 * 1024).addOnSuccessListener(new OnSuccessListener<byte[]>() {
                            @Override
                            public void onSuccess(byte[] bytes) {
                                Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                                imageView.setImageBitmap(bitmap);
                            }
                        });
                        Glide.with(SingleProduct.this).load(img_url).into(imageView);
                        textView1.setText(snapshot.get("product_brand_name") + " " + snapshot.get("product_name"));
                        textView2.setText("Rs. " + snapshot.get("product_price") + ".00");
                        textView3.setText(snapshot.get("product_description") + "");

                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
            }
        });

        btn_buy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int intqty = Integer.parseInt(qty);
                int netqty = intqty - 1;
                db.collection("Product").document(documentid).update("product_qty", netqty + "");
                if (netqty == 0) {
                    db.collection("Product").document(documentid).update("product_status", "Sold Out");
                }

                Buy buy = new Buy();
                buy.setProduct_document(documentid);
                buy.setCustomer_document(customerdoc);
                buy.setCardno(card_no.getText().toString());
                buy.setEx_month(ex_mo.getText().toString());
                buy.setEx_year(ex_ye.getText().toString());
                buy.setOrder_date(new Date().toString());
                buy.setSec_no(s_co.getText().toString());
                buy.setOrder_qty("1");

                db.collection("Invoice").add(buy).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Intent intent = new Intent(SingleProduct.this, Home.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(SingleProduct.this, "Purchesing is Failed", Toast.LENGTH_SHORT).show();
                    }
                });

            }
        });

    }
}