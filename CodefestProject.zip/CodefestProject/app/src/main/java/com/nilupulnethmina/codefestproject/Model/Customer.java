package com.nilupulnethmina.codefestproject.Model;

public class Customer {
    String cus_google_id;
    String cus_name;
    String cus_email;
    String cus_nic_no;
    String cus_mobile_no;
    String cus_gender;
    String cus_addline1;
    String cus_addline2;
    String cus_addcity;
    String cus_addzipcode;
    String cus_token_id;

    public Customer() {
    }

    public Customer(String cus_google_id, String cus_name, String cus_email, String cus_nic_no, String cus_mobile_no, String cus_gender, String cus_addline1, String cus_addline2, String cus_addcity, String cus_addzipcode, String cus_token_id) {
        this.cus_google_id = cus_google_id;
        this.cus_name = cus_name;
        this.cus_email = cus_email;
        this.cus_nic_no = cus_nic_no;
        this.cus_mobile_no = cus_mobile_no;
        this.cus_gender = cus_gender;
        this.cus_addline1 = cus_addline1;
        this.cus_addline2 = cus_addline2;
        this.cus_addcity = cus_addcity;
        this.cus_addzipcode = cus_addzipcode;
        this.cus_token_id = cus_token_id;
    }

    public String getCus_google_id() {
        return cus_google_id;
    }

    public void setCus_google_id(String cus_google_id) {
        this.cus_google_id = cus_google_id;
    }

    public String getCus_name() {
        return cus_name;
    }

    public void setCus_name(String cus_name) {
        this.cus_name = cus_name;
    }

    public String getCus_email() {
        return cus_email;
    }

    public void setCus_email(String cus_email) {
        this.cus_email = cus_email;
    }

    public String getCus_nic_no() {
        return cus_nic_no;
    }

    public void setCus_nic_no(String cus_nic_no) {
        this.cus_nic_no = cus_nic_no;
    }

    public String getCus_mobile_no() {
        return cus_mobile_no;
    }

    public void setCus_mobile_no(String cus_mobile_no) {
        this.cus_mobile_no = cus_mobile_no;
    }

    public String getCus_gender() {
        return cus_gender;
    }

    public void setCus_gender(String cus_gender) {
        this.cus_gender = cus_gender;
    }

    public String getCus_addline1() {
        return cus_addline1;
    }

    public void setCus_addline1(String cus_addline1) {
        this.cus_addline1 = cus_addline1;
    }

    public String getCus_addline2() {
        return cus_addline2;
    }

    public void setCus_addline2(String cus_addline2) {
        this.cus_addline2 = cus_addline2;
    }

    public String getCus_addcity() {
        return cus_addcity;
    }

    public void setCus_addcity(String cus_addcity) {
        this.cus_addcity = cus_addcity;
    }

    public String getCus_addzipcode() {
        return cus_addzipcode;
    }

    public void setCus_addzipcode(String cus_addzipcode) {
        this.cus_addzipcode = cus_addzipcode;
    }

    public String getCus_token_id() {
        return cus_token_id;
    }

    public void setCus_token_id(String cus_token_id) {
        this.cus_token_id = cus_token_id;
    }
}
