package com.nilupulnethmina.codefestprojectadmin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.nilupulnethmina.codefestprojectadmin.Model.Product;

public class MainActivity extends AppCompatActivity {

    EditText pro_brand, pro_name, pro_price, pro_qty, pro_description;
    ImageView pro_image;
    Button btn_add, btn_save, btn_back;
    Uri filePath;
    String product_image_path;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    StorageReference storageReference = FirebaseStorage.getInstance().getReference();
    String productstatus = "Available";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pro_brand = findViewById(R.id.brand);
        pro_name = findViewById(R.id.name);
        pro_price = findViewById(R.id.price);
        pro_qty = findViewById(R.id.qty);
        pro_description = findViewById(R.id.description);

        btn_add = findViewById(R.id.add);
        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent fileChoser = new Intent(Intent.ACTION_GET_CONTENT);
                fileChoser.setType("*/*");
                startActivityForResult(fileChoser, 1);
            }
        });

        btn_back = findViewById(R.id.button5);
        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Home.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });

        btn_save = findViewById(R.id.save);
        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String productbrand = pro_brand.getText().toString();
                String productname = pro_name.getText().toString();
                String productprice = pro_price.getText().toString();
                String productqty = pro_qty.getText().toString();
                String productdescription = pro_description.getText().toString();

                try {
                    String path = productbrand + "_" + productname + "_" + System.currentTimeMillis() + ".png";
                    product_image_path = "product_image/" + path;

                    Product product = new Product();
                    product.setProduct_status(productstatus);
                    product.setProduct_qty(productqty);
                    product.setPriduct_image(product_image_path);
                    product.setProduct_description(productdescription);
                    product.setProduct_price(productprice);
                    product.setProduct_name(productname);
                    product.setProduct_brand_name(productbrand);

                    UploadTask uploadTask = storageReference.child(product_image_path).putFile(filePath);
                    uploadTask.addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception exception) {
                        }
                    }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            taskSnapshot.getUploadSessionUri();
                        }
                    });

                    db.collection("Product").add(product).addOnSuccessListener(
                            new OnSuccessListener<DocumentReference>() {
                                @Override
                                public void onSuccess(DocumentReference documentReference) {
                                    finish();
                                    startActivity(getIntent());
                                }
                            }
                    ).addOnFailureListener(
                            new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {

                                }
                            }
                    );
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
                filePath = data.getData();
                try {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(MainActivity.this.getContentResolver(), filePath);
                    pro_image = findViewById(R.id.imageView2);
                    pro_image.setImageBitmap(bitmap);   //  Image
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
}