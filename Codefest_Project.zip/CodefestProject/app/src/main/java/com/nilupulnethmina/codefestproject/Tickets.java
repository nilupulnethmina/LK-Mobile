package com.nilupulnethmina.codefestproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Tickets extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Tickets");
        setContentView(R.layout.activity_tickets);
    }
}