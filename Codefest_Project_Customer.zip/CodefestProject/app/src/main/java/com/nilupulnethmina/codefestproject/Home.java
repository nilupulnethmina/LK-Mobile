package com.nilupulnethmina.codefestproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.firebase.ui.auth.AuthUI;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.nilupulnethmina.codefestproject.Adapter.ProductAapter;
import com.nilupulnethmina.codefestproject.Model.Customer;
import com.nilupulnethmina.codefestproject.Model.News;
import com.nilupulnethmina.codefestproject.Model.Product;

import java.util.List;

public class Home extends AppCompatActivity {

    GridLayoutManager gridLayoutManager;
    private RecyclerView recyclerView;
    private ProductAapter productAapter;

    TextView cusname, cusemail, cusmobile;
    ImageView cusprofile;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private StorageReference storageRef = FirebaseStorage.getInstance().getReference();

    Button btn_tickets, btn_news, btn_logout;
    private SwipeRefreshLayout swipeRefreshLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        cusname = findViewById(R.id.profile_name);
        cusemail = findViewById(R.id.profile_email);
        cusmobile = findViewById(R.id.profile_mobile);
        cusprofile = findViewById(R.id.profile_image);

        getData();

        btn_tickets = findViewById(R.id.button4);
        btn_tickets.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Home.this, Tickets.class));
            }
        });

        btn_news = findViewById(R.id.button3);
        btn_news.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Home.this, NewsActivity.class));
            }
        });

        btn_logout = findViewById(R.id.btnlogout);
        btn_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AuthUI.getInstance()
                        .signOut(Home.this)
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            public void onComplete(@NonNull Task<Void> task) {
                                Intent intent = new Intent(Home.this, MainActivity.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                                startActivity(intent);
                                finish();
                            }
                        });
            }
        });

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        String user_email = user.getEmail();

        db.collection("Customer").whereEqualTo("cus_email", user_email).get().addOnSuccessListener(
                new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        List<Customer> riders = queryDocumentSnapshots.toObjects(Customer.class);
                        if (riders.size() > 0) {
                            Customer customer = riders.get(0);
                            cusname.setText(customer.getCus_name());
                            cusemail.setText(customer.getCus_email());
                            cusmobile.setText(customer.getCus_mobile_no());
                            Uri profileImage = user.getPhotoUrl();
                            Glide.with(Home.this).load(profileImage).into(cusprofile);
                        }
                    }
                }
        ).addOnFailureListener(
                new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                }
        );

        swipeRefreshLayout = findViewById(R.id.refreshproductlayout);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                getData();
                swipeRefreshLayout.setRefreshing(false);
            }
        });


    }

    private void getData() {
        db.collection("Product").whereEqualTo("product_status", "Available").get().addOnSuccessListener(
                new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        List<Product> products = queryDocumentSnapshots.toObjects(Product.class);
                        recyclerView = findViewById(R.id.product_view_layout_content);
                        productAapter = new ProductAapter(Home.this, products);
                        recyclerView.setAdapter(productAapter);
                        gridLayoutManager = new GridLayoutManager(Home.this, 2);
                        recyclerView.setLayoutManager(gridLayoutManager);
                    }
                }
        ).addOnFailureListener(
                new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                }
        );
    }
}