package com.nilupulnethmina.codefestproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.nilupulnethmina.codefestproject.Model.Customer;

public class Register extends AppCompatActivity {

    EditText user_name, user_email, user_mobile, user_nic, user_addline1, user_addline2, user_addcity, user_addzipcode;
    RadioGroup radioGroup;
    RadioButton radioButton;
    String cus_name, cus_email, cus_id, cus_token, cus_gender;
    Button register;
    FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Customer Register");
        setContentView(R.layout.activity_register);

        user_name = findViewById(R.id.cus_name);
        user_email = findViewById(R.id.cus_email);
        user_mobile = findViewById(R.id.cus_mobile);
        user_nic = findViewById(R.id.cus_nic);
        radioGroup = findViewById(R.id.radioGenderGroup);
        user_addline1 = findViewById(R.id.addline1);
        user_addline2 = findViewById(R.id.addline2);
        user_addcity = findViewById(R.id.city);
        user_addzipcode = findViewById(R.id.zipcode);

        Bundle bundle = getIntent().getExtras();
        cus_name = bundle.getString("auth_name");
        cus_email = bundle.getString("auth_email");
        cus_id = bundle.getString("auth_id");
        cus_token = bundle.getString("fcm_token");

        user_name.setText(cus_name);
        user_email.setText(cus_email);

        register = findViewById(R.id.btn_register);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Customer c = new Customer();
                c.setCus_google_id(cus_id);
                c.setCus_token_id(cus_token);
                c.setCus_name(user_name.getText().toString());
                c.setCus_email(user_email.getText().toString());
                c.setCus_mobile_no(user_mobile.getText().toString());
                c.setCus_nic_no(user_nic.getText().toString());
                c.setCus_gender(cus_gender);
                c.setCus_addline1(user_addline1.getText().toString());
                c.setCus_addline2(user_addline2.getText().toString());
                c.setCus_addcity(user_addcity.getText().toString());
                c.setCus_addzipcode(user_addzipcode.getText().toString());

                db.collection("Customer").add(c).addOnSuccessListener(
                        new OnSuccessListener<DocumentReference>() {
                            @Override
                            public void onSuccess(DocumentReference documentReference) {
                                Intent intent = new Intent(Register.this, Home.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                            }
                        }
                ).addOnFailureListener(
                        new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {

                            }
                        }
                );
            }
        });

    }

    public void checkButton(View v) {
        int radioInt = radioGroup.getCheckedRadioButtonId();
        radioButton = findViewById(radioInt);
        cus_gender = radioButton.getText().toString();
    }
}