package com.nilupulnethmina.codefestprojectadmin.Model;

public class Product {
    String product_brand_name;
    String product_name;
    String product_price;
    String priduct_image;
    String product_qty;
    String product_description;
    String product_status;

    public Product() {
    }

    public Product(String product_brand_name, String product_name, String product_price, String priduct_image, String product_qty, String product_description, String product_status) {
        this.product_brand_name = product_brand_name;
        this.product_name = product_name;
        this.product_price = product_price;
        this.priduct_image = priduct_image;
        this.product_qty = product_qty;
        this.product_description = product_description;
        this.product_status = product_status;
    }

    public String getProduct_brand_name() {
        return product_brand_name;
    }

    public void setProduct_brand_name(String product_brand_name) {
        this.product_brand_name = product_brand_name;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public String getProduct_price() {
        return product_price;
    }

    public void setProduct_price(String product_price) {
        this.product_price = product_price;
    }

    public String getPriduct_image() {
        return priduct_image;
    }

    public void setPriduct_image(String priduct_image) {
        this.priduct_image = priduct_image;
    }

    public String getProduct_qty() {
        return product_qty;
    }

    public void setProduct_qty(String product_qty) {
        this.product_qty = product_qty;
    }

    public String getProduct_description() {
        return product_description;
    }

    public void setProduct_description(String product_description) {
        this.product_description = product_description;
    }

    public String getProduct_status() {
        return product_status;
    }

    public void setProduct_status(String product_status) {
        this.product_status = product_status;
    }
}
