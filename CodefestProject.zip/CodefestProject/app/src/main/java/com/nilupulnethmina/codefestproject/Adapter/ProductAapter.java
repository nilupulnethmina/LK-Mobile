package com.nilupulnethmina.codefestproject.Adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.nilupulnethmina.codefestproject.Model.Product;
import com.nilupulnethmina.codefestproject.R;
import com.nilupulnethmina.codefestproject.SingleProduct;

import java.util.List;

public class ProductAapter extends RecyclerView.Adapter<ProductAapter.MyViewHolder> {

    private Context mCtx;
    private List<Product> p_list;
    private LayoutInflater inflater;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private StorageReference storageRef = FirebaseStorage.getInstance().getReference();

    public ProductAapter(Context mCtx, List<Product> p_list) {
        this.mCtx = mCtx;
        this.p_list = p_list;
        this.inflater = LayoutInflater.from(mCtx);
    }

    @NonNull
    @Override
    public ProductAapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.producy_layout, parent, false);
        return new ProductAapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductAapter.MyViewHolder holder, int position) {
        Product product = p_list.get(position);

        if (!product.equals("null")) {
            String img_url = product.getPriduct_image();

            storageRef.child(img_url).getBytes(1024 * 1024).addOnSuccessListener(new OnSuccessListener<byte[]>() {
                @Override
                public void onSuccess(byte[] bytes) {
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    holder.imgproduct.setImageBitmap(bitmap);
                }
            });

            Glide.with(mCtx).load(img_url).into(holder.imgproduct);

            holder.txt1.setText(product.getProduct_brand_name());
            holder.txt2.setText(product.getProduct_name());
            holder.txt3.setText("Rs. " + product.getProduct_price() + ".00");
            holder.txt4.setText("Qty : " + product.getProduct_qty());

            holder.linearLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    db.collection("Product").whereEqualTo("product_brand_name", product.getProduct_brand_name()).whereEqualTo("product_name", product.getProduct_name()).get()
                            .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                                @Override
                                public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                                    List<Product> products = queryDocumentSnapshots.toObjects(Product.class);
                                    if (products.size() > 0) {
                                        DocumentSnapshot snapshot = queryDocumentSnapshots.getDocuments().get(0);
                                        holder.productDocumentID = snapshot.getId();
                                        SingleProduct.documentid = holder.productDocumentID;
                                        Intent intent = new Intent(mCtx, SingleProduct.class);
                                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        mCtx.startActivity(intent);
                                    }
                                }
                            });
                }
            });
        } else {
            Toast.makeText(mCtx, "No Product Found", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public int getItemCount() {
        return p_list.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView txt1, txt2, txt3, txt4;
        LinearLayout linearLayout;
        ImageView imgproduct;
        public String productDocumentID;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            txt1 = itemView.findViewById(R.id.productbrand);
            txt2 = itemView.findViewById(R.id.productname);
            txt3 = itemView.findViewById(R.id.productprice);
            txt4 = itemView.findViewById(R.id.productqty);
            imgproduct = itemView.findViewById(R.id.productimg);
            linearLayout = itemView.findViewById(R.id.product_layout_content);

        }
    }
}
