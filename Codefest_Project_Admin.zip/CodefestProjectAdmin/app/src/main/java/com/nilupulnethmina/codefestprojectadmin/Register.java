package com.nilupulnethmina.codefestprojectadmin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.nilupulnethmina.codefestprojectadmin.Model.Admin;

public class Register extends AppCompatActivity {

    EditText name, email, mobile;
    Button regi;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    private String admin_name, admin_email, admin_id, admin_token, admin_mobile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        Bundle bundle = getIntent().getExtras();
        admin_name = bundle.getString("auth_name");
        admin_email = bundle.getString("auth_email");
        admin_id = bundle.getString("auth_id");
        admin_token = bundle.getString("fcm_token");

        name = findViewById(R.id.ad_name);
        email = findViewById(R.id.ad_email);
        mobile = findViewById(R.id.ad_mobile);

        name.setText(admin_name.toString());
        email.setText(admin_email.toString());
        admin_mobile = mobile.getText().toString();

        regi = findViewById(R.id.btn_register);
        regi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Admin admin = new Admin();
                admin.setAdmin_name(admin_name);
                admin.setAdmin_email(admin_email);
                admin.setAdmin_mobile(admin_mobile);
                admin.setAdmin_googlrid(admin_id);
                admin.setAdmin_token(admin_token);

                db.collection("Admin").add(admin)
                        .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                            @Override
                            public void onSuccess(DocumentReference documentReference) {
                                Intent intent = new Intent(Register.this, Home.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                });
            }
        });
    }
}