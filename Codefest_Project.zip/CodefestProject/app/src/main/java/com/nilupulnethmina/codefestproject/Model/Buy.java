package com.nilupulnethmina.codefestproject.Model;

public class Buy {
    String product_document;
    String customer_document;
    String cardno;
    String ex_month;
    String ex_year;
    String sec_no;
    String order_date;
    String order_qty;

    public Buy() {
    }

    public Buy(String product_document, String customer_document, String cardno, String ex_month, String ex_year, String sec_no, String order_date, String order_qty) {
        this.product_document = product_document;
        this.customer_document = customer_document;
        this.cardno = cardno;
        this.ex_month = ex_month;
        this.ex_year = ex_year;
        this.sec_no = sec_no;
        this.order_date = order_date;
        this.order_qty = order_qty;
    }

    public String getProduct_document() {
        return product_document;
    }

    public void setProduct_document(String product_document) {
        this.product_document = product_document;
    }

    public String getCustomer_document() {
        return customer_document;
    }

    public void setCustomer_document(String customer_document) {
        this.customer_document = customer_document;
    }

    public String getCardno() {
        return cardno;
    }

    public void setCardno(String cardno) {
        this.cardno = cardno;
    }

    public String getEx_month() {
        return ex_month;
    }

    public void setEx_month(String ex_month) {
        this.ex_month = ex_month;
    }

    public String getEx_year() {
        return ex_year;
    }

    public void setEx_year(String ex_year) {
        this.ex_year = ex_year;
    }

    public String getSec_no() {
        return sec_no;
    }

    public void setSec_no(String sec_no) {
        this.sec_no = sec_no;
    }

    public String getOrder_date() {
        return order_date;
    }

    public void setOrder_date(String order_date) {
        this.order_date = order_date;
    }

    public String getOrder_qty() {
        return order_qty;
    }

    public void setOrder_qty(String order_qty) {
        this.order_qty = order_qty;
    }
}
