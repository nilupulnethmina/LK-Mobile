package com.nilupulnethmina.codefestprojectadmin.Model;

public class Admin {
    String admin_googlrid;
    String admin_name;
    String admin_email;
    String admin_mobile;
    String admin_token;

    public Admin() {
    }

    public Admin(String admin_googlrid, String admin_name, String admin_email, String admin_mobile, String admin_token) {
        this.admin_googlrid = admin_googlrid;
        this.admin_name = admin_name;
        this.admin_email = admin_email;
        this.admin_mobile = admin_mobile;
        this.admin_token = admin_token;
    }

    public String getAdmin_googlrid() {
        return admin_googlrid;
    }

    public void setAdmin_googlrid(String admin_googlrid) {
        this.admin_googlrid = admin_googlrid;
    }

    public String getAdmin_name() {
        return admin_name;
    }

    public void setAdmin_name(String admin_name) {
        this.admin_name = admin_name;
    }

    public String getAdmin_email() {
        return admin_email;
    }

    public void setAdmin_email(String admin_email) {
        this.admin_email = admin_email;
    }

    public String getAdmin_mobile() {
        return admin_mobile;
    }

    public void setAdmin_mobile(String admin_mobile) {
        this.admin_mobile = admin_mobile;
    }

    public String getAdmin_token() {
        return admin_token;
    }

    public void setAdmin_token(String admin_token) {
        this.admin_token = admin_token;
    }
}
