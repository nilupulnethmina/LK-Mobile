package com.nilupulnethmina.codefestproject.Model;

public class News {
    String news_title;
    String news_message;
    String product_docunemt;
    String news_date;

    public News() {
    }

    public News(String news_title, String news_message, String product_docunemt, String news_date) {
        this.news_title = news_title;
        this.news_message = news_message;
        this.product_docunemt = product_docunemt;
        this.news_date = news_date;
    }

    public String getNews_title() {
        return news_title;
    }

    public void setNews_title(String news_title) {
        this.news_title = news_title;
    }

    public String getNews_message() {
        return news_message;
    }

    public void setNews_message(String news_message) {
        this.news_message = news_message;
    }

    public String getProduct_docunemt() {
        return product_docunemt;
    }

    public void setProduct_docunemt(String product_docunemt) {
        this.product_docunemt = product_docunemt;
    }

    public String getNews_date() {
        return news_date;
    }

    public void setNews_date(String news_date) {
        this.news_date = news_date;
    }
}
