package com.nilupulnethmina.codefestprojectadmin.Model;

public class Ticket {
    String customer_doc_id;
    String type_ticket;
    String title_ticket;
    String message_ticket;
    String attach_file_ticket;

    public Ticket() {
    }

    public Ticket(String customer_doc_id, String type_ticket, String title_ticket, String message_ticket, String attach_file_ticket) {
        this.customer_doc_id = customer_doc_id;
        this.type_ticket = type_ticket;
        this.title_ticket = title_ticket;
        this.message_ticket = message_ticket;
        this.attach_file_ticket = attach_file_ticket;
    }

    public String getCustomer_doc_id() {
        return customer_doc_id;
    }

    public void setCustomer_doc_id(String customer_doc_id) {
        this.customer_doc_id = customer_doc_id;
    }

    public String getType_ticket() {
        return type_ticket;
    }

    public void setType_ticket(String type_ticket) {
        this.type_ticket = type_ticket;
    }

    public String getTitle_ticket() {
        return title_ticket;
    }

    public void setTitle_ticket(String title_ticket) {
        this.title_ticket = title_ticket;
    }

    public String getMessage_ticket() {
        return message_ticket;
    }

    public void setMessage_ticket(String message_ticket) {
        this.message_ticket = message_ticket;
    }

    public String getAttach_file_ticket() {
        return attach_file_ticket;
    }

    public void setAttach_file_ticket(String attach_file_ticket) {
        this.attach_file_ticket = attach_file_ticket;
    }
}
