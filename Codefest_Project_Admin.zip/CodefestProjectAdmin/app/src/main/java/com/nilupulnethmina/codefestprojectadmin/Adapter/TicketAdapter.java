package com.nilupulnethmina.codefestprojectadmin.Adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.nilupulnethmina.codefestprojectadmin.Model.Ticket;
import com.nilupulnethmina.codefestprojectadmin.R;
import com.nilupulnethmina.codefestprojectadmin.Tickets;

import java.util.List;

public class TicketAdapter extends RecyclerView.Adapter<TicketAdapter.MyViewHolder> {

    private Context mCtx;
    private List<Ticket> p_list;
    private LayoutInflater inflater;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private StorageReference storageRef = FirebaseStorage.getInstance().getReference();

    public TicketAdapter(Context mCtx, List<Ticket> p_list) {
        this.mCtx = mCtx;
        this.p_list = p_list;
        this.inflater = LayoutInflater.from(mCtx);
    }

    @NonNull
    @Override
    public TicketAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.ticket_layout, parent, false);
        return new TicketAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TicketAdapter.MyViewHolder holder, int position) {
        Ticket ticket = p_list.get(position);

        if (!ticket.equals("null")) {

            holder.txt1.setText(ticket.getType_ticket());
            holder.txt2.setText(ticket.getTitle_ticket());
            holder.txt3.setText(ticket.getMessage_ticket());
            if (ticket.getAttach_file_ticket() != null) {
                holder.txt4.setText(ticket.getAttach_file_ticket());
            } else {
                holder.txt4.setText("null");
            }
            db.collection("Customer").document(ticket.getCustomer_doc_id()).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                @Override
                public void onSuccess(DocumentSnapshot snapshot) {
                    holder.txt5.setText(snapshot.get("cus_email").toString());
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {

                }
            });

            holder.btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    db.collection("Tickets")
                            .whereEqualTo("type_ticket", ticket.getType_ticket())
                            .whereEqualTo("title_ticket", ticket.getTitle_ticket())
                            .whereEqualTo("message_ticket", ticket.getMessage_ticket()).get()
                            .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                                @Override
                                public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                                    List<Ticket> tickets = queryDocumentSnapshots.toObjects(Ticket.class);
                                    if (tickets.size() > 0) {
                                        DocumentSnapshot snapshot = queryDocumentSnapshots.getDocuments().get(0);
                                        holder.ticketDocumentID = snapshot.getId();
                                        db.collection("Tickets").document(holder.ticketDocumentID).update("status", "View")
                                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                    @Override
                                                    public void onSuccess(Void aVoid) {
                                                        mCtx.startActivity(new Intent(mCtx, Tickets.class));
                                                    }
                                                }).addOnFailureListener(new OnFailureListener() {
                                            @Override
                                            public void onFailure(@NonNull Exception e) {

                                            }
                                        });
                                    }
                                }
                            });
                }
            });

        } else {
            Toast.makeText(mCtx, "No Product Found", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public int getItemCount() {
        return p_list.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView txt1, txt2, txt3, txt4, txt5;
        LinearLayout linearLayout;
        Button btn;
        public String ticketDocumentID;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            txt1 = itemView.findViewById(R.id.textView10);
            txt2 = itemView.findViewById(R.id.textView11);
            txt3 = itemView.findViewById(R.id.textView12);
            txt4 = itemView.findViewById(R.id.textView13);
            txt5 = itemView.findViewById(R.id.textView14);
            btn = itemView.findViewById(R.id.button6);
            linearLayout = itemView.findViewById(R.id.ticket_layout_content);
        }
    }
}